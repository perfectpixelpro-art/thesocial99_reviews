import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as ArrowRight, _ as CircleCheck, b as Check, g as CircleX } from "../_libs/lucide-react.mjs";
import { i as cn, r as SiteShell, t as COMPARISONS } from "./comparisons-4oUkJES9.mjs";
import { a as TableOfContents, c as buildHead, f as keywordsForPage, i as ProsConsBox, m as mergedFaqsForPage, o as absoluteUrl, r as PRICING, s as breadcrumbJsonLd, t as AuthorByline, u as faqPageJsonLd } from "./faqSchema-C_Qcepuv.mjs";
import { t as Breadcrumb } from "./breadcrumb-ML1wJytH.mjs";
import { n as FAQAccordion, r as QuickAnswerBox, t as CTABanner } from "./cta-banner-BGPKr5tk.mjs";
import { a as RatingStars, i as REVIEW_FAQS, o as ReviewCard, r as REVIEWS, t as CTAButton } from "./faqs-CLF7t3zH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/review-page-BEDLyamV.js
var import_jsx_runtime = require_jsx_runtime();
function PricingTable({ tiers, pageSlug }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-5 md:grid-cols-3",
		children: tiers.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("flex flex-col rounded-2xl border bg-card p-6 shadow-[var(--shadow-card)]", t.highlight ? "border-primary ring-1 ring-primary/40" : "border-border"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-[650] text-ink",
						children: t.name
					}), t.highlight && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-primary px-2.5 py-1 text-[10px] font-[650] uppercase tracking-wider text-primary-foreground",
						children: "Most picked"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-baseline gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-4xl font-[650] tracking-tight text-ink",
						children: ["$", t.price]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm text-muted-foreground",
						children: ["/", t.cadence]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: t.tagline
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 flex-1 space-y-2.5",
					children: t.features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-2 text-sm text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							size: 16,
							className: "mt-0.5 flex-none text-success",
							strokeWidth: 2.5
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: f })]
					}, f))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CTAButton, {
						variant: t.highlight ? "secondary" : "secondary",
						action: "trial",
						pageSlug,
						className: "w-full",
						children: ["Start with ", t.name]
					})
				})
			]
		}, t.name))
	});
}
var OVERALL_RATING = 4.8;
var SLUG = "the-social-99-review";
var LAST_UPDATED = "2026-07-02";
var TOC = [
	{
		id: "verdict",
		label: "Verdict"
	},
	{
		id: "pros-cons",
		label: "Pros & cons"
	},
	{
		id: "what-you-get",
		label: "What you get"
	},
	{
		id: "pricing",
		label: "Pricing"
	},
	{
		id: "scored",
		label: "Scored sections"
	},
	{
		id: "who-should",
		label: "Who should use"
	},
	{
		id: "alternatives",
		label: "vs alternatives"
	},
	{
		id: "client-reviews",
		label: "Client reviews"
	},
	{
		id: "faqs",
		label: "FAQs"
	}
];
var scored = [
	{
		title: "Ease of use",
		score: 4.9,
		answer: "Effortless - the client does almost nothing. Onboarding is a short brand call and a Google Drive folder; publishing happens without you opening a scheduler."
	},
	{
		title: "Content quality",
		score: 4.7,
		answer: "Consistently on-brand and clearly human-made. Not viral-agency spectacle, but far above what a $99 price point implies."
	},
	{
		title: "After-sales support",
		score: 4.9,
		answer: "Review-before-publish on every plan and unlimited revisions on Premium set a bar most agencies at 5–10× the price don't meet."
	},
	{
		title: "Reliability",
		score: 4.8,
		answer: "Weekly cadence is the whole product. In our tracking window posts shipped on schedule with the exception of one holiday week that was flagged in advance."
	}
];
function ReviewPageView() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "container-page py-10 md:py-14",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Breadcrumb, { items: [{
			label: "Home",
			to: "/"
		}, { label: "The Social 99 Review" }] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-12 lg:grid-cols-[1fr_220px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs font-[650] uppercase tracking-wider text-primary",
					children: "First-party review"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-3xl font-[650] leading-[1.15] tracking-tight text-ink md:text-5xl",
					children: "The Social 99 Review (2026): Is It Worth the $99/Month?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthorByline, {
						name: "Reviewed by The Social 99 Editorial",
						role: "Updated July 2026",
						lastUpdated: LAST_UPDATED,
						methodology: "Methodology: This review is based on our operational data, service documentation, quality audits, customer feedback, and ongoing performance reviews. All published customer testimonials are genuine and shared with permission."
					})
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-10 prose-article",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "verdict",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-6 rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)] md:flex-row md:items-center md:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-[650] uppercase tracking-wider text-muted-foreground",
									children: "Overall"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex items-baseline gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-4xl font-[650] text-ink",
										children: OVERALL_RATING.toFixed(1)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-muted-foreground",
										children: "/ 5.0"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RatingStars, {
									rating: OVERALL_RATING,
									className: "mt-2"
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "max-w-xl text-sm text-muted-foreground",
								children: "Editorial Rating: 4.8/5 Our editorial score reflects service quality, customer experience, value for money, ease of use, content quality, and ongoing support. It is based on internal operational data and verified customer feedback."
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickAnswerBox, {
								title: "Quick summary",
								children: "The Social 99 is an excellent choice for small businesses looking for affordable, done-for-you social media management. Starting at $99/month, it includes content creation, graphic design, scheduling, publishing, and ongoing support. While it may not suit businesses needing enterprise workflows or highly customized marketing strategies, it offers exceptional value for companies seeking a simple and reliable social media solution."
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "pros-cons",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Pros & Cons of The Social 99" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-sm font-[650] text-success",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 18 }), " Pros"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "mt-3 space-y-2 text-sm text-ink",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Fully done-for-you social media management." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Transparent monthly pricing with no setup fee." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Human-created content tailored to your brand." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Review and approval before content is published." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Optional short-form video and website support." })
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-sm font-[650] text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { size: 18 }), " Honest limitations"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "mt-3 space-y-2 text-sm text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Best suited for businesses that want a team-managed service rather than a self-serve scheduling tool." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Short-form video content is included only on Growth and Premium plans." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Designed primarily for small and local businesses, not enterprise organizations with complex approval workflows." })
									]
								})]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "what-you-get",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "What's Included with The Social 99" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Every The Social 99 plan includes content planning, copywriting, graphic design, scheduling, publishing, and ongoing support. Optional short-form video and website services are available on select plans." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-4 md:grid-cols-3",
								children: [
									{
										t: "Done-for-You Social Media Management",
										d: "Content strategy, graphics, captions, scheduling, publishing, and monthly support across the platforms your business uses most."
									},
									{
										t: "Short-Form Video Content",
										d: "Reels, TikToks, and short-form videos created from templates or your footage, available on Growth and Premium plans."
									},
									{
										t: "Website & Landing Page Support",
										d: "Landing pages, microsites, and website updates designed to match your brand and support your marketing funnel."
									}
								].map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-card)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-sm font-[650] text-ink",
										children: b.t
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1.5 text-sm text-muted-foreground",
										children: b.d
									})]
								}, b.t))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "pricing",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "The Social 99 Pricing & Plans" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The Social 99 offers three flexible monthly plans starting at $99/month. Every plan includes human-created content, no setup fees, no long-term contracts, and month-to-month billing." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "not-prose",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PricingTable, {
									tiers: PRICING,
									pageSlug: SLUG
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "scored",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Scored sections" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-4",
							children: scored.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-card)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-base font-[650] text-ink",
										children: s.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-[650] text-ink",
											children: s.score.toFixed(1)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RatingStars, { rating: s.score })]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted-foreground",
									children: s.answer
								})]
							}, s.title))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "who-should",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Who should use it - and who should skip it" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProsConsBox, {
								title: "Use it if you're…",
								tone: "us",
								pros: [
									"A local service business (med spa, salon, restaurant, bar, pet grooming).",
									"Currently DIY-ing and posting inconsistently.",
									"Comparing agency quotes at $1.5k–$5k/mo.",
									"Camera-shy or short on production time."
								],
								cons: []
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProsConsBox, {
								title: "Skip it if you're…",
								tone: "them",
								pros: [
									"Already staffed with an in-house creator/manager.",
									"Running enterprise approval chains or multi-brand roll-ups.",
									"Looking for a self-serve tool with a UI you operate."
								],
								cons: []
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "alternatives",
						className: "not-prose",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-4 mt-10 text-2xl font-[650] text-ink",
							children: "vs alternatives (quick view)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden rounded-2xl border border-border shadow-[var(--shadow-card)]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full border-collapse text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "bg-tint/60",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-3 text-left text-xs font-[650] uppercase tracking-wider text-primary",
												children: "Compared with"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-3 text-left text-xs font-[650] uppercase tracking-wider text-muted-foreground",
												children: "Model"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-3 text-left text-xs font-[650] uppercase tracking-wider text-muted-foreground",
												children: "Read"
											})
										]
									}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: COMPARISONS.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: i % 2 === 1 ? "bg-surface/50" : "bg-background",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												scope: "row",
												className: "px-4 py-3 text-left font-[600] text-ink",
												children: c.competitor
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-muted-foreground",
												children: "Self-serve tool"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
													to: "/blog/$slug",
													params: { slug: c.slug },
													className: "inline-flex items-center gap-1 text-primary hover:underline",
													children: [
														"Full comparison",
														" ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 14 })
													]
												})
											})
										]
									}, c.slug)) })]
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "client-reviews",
						className: "not-prose",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-4 mt-10 text-2xl font-[650] text-ink",
								children: "Real client reviews"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-4 text-sm text-muted-foreground",
								children: "Every review published on this page is shared with the client's permission and reflects a real customer experience"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-4 md:grid-cols-3",
								children: REVIEWS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewCard, { review: r }, r.id))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "faqs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Frequently asked questions" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FAQAccordion, {
							faqs: REVIEW_FAQS,
							idPrefix: "review"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "not-prose",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CTABanner, {
							pageSlug: SLUG,
							headline: "Try The Social 99 free",
							sub: "A real trial with real content - see the workflow before you commit to a plan."
						})
					})
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableOfContents, { items: TOC }) })]
		})]
	}) });
}
function reviewHead() {
	const path = `/${SLUG}`;
	const title = "The Social 99 Review (2026): Is the $99 Done-For-You Service Worth It?";
	const description = "Honest, first-party 2026 review of The Social 99: pricing, what you get, pros, honest limitations, scored sections, and how it compares. Operated by The Social 99.";
	const reviewJsonLd = {
		"@context": "https://schema.org",
		"@type": "Review",
		itemReviewed: {
			"@type": "Service",
			name: "The Social 99",
			provider: {
				"@type": "Organization",
				name: "The Social 99",
				url: "https://thesocial99.com"
			}
		},
		author: {
			"@type": "Organization",
			name: "The Social 99 Editorial"
		},
		datePublished: LAST_UPDATED,
		reviewBody: "For most US small businesses needing consistent posting on 1–3 platforms, The Social 99 is the most cost-effective way to fully outsource social media.",
		reviewRating: {
			"@type": "Rating",
			ratingValue: OVERALL_RATING,
			bestRating: 5
		},
		url: absoluteUrl(path)
	};
	const faqs = mergedFaqsForPage("R", REVIEW_FAQS);
	return buildHead({
		title,
		description,
		path,
		type: "article",
		keywords: keywordsForPage("R", "High").slice(0, 12).map((k) => k.keyword),
		jsonLd: [
			reviewJsonLd,
			faqPageJsonLd(faqs),
			breadcrumbJsonLd([{
				name: "Home",
				path: "/"
			}, {
				name: "The Social 99 Review",
				path
			}])
		]
	});
}
//#endregion
export { reviewHead as n, ReviewPageView as t };
