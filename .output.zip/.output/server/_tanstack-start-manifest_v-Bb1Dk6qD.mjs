//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bb1Dk6qD.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/utkarsh/Desktop/thesocial99_reviews/src/routes/__root.tsx",
		children: [
			"/",
			"/sitemap.xml",
			"/the-social-99-review",
			"/blog/$slug",
			"/blog/"
		],
		preloads: [
			"/assets/index-DFiyF1xx.js",
			"/assets/comparisons-juijGhWa.js",
			"/assets/arrow-right-C9vu6YO4.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DFiyF1xx.js"
		} }]
	},
	"/": {
		filePath: "/Users/utkarsh/Desktop/thesocial99_reviews/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Bs0db6dx.js"]
	},
	"/the-social-99-review": {
		filePath: "/Users/utkarsh/Desktop/thesocial99_reviews/src/routes/the-social-99-review.tsx",
		children: void 0,
		preloads: ["/assets/the-social-99-review-Ddi7cGC_.js"]
	},
	"/blog/$slug": {
		filePath: "/Users/utkarsh/Desktop/thesocial99_reviews/src/routes/blog.$slug.tsx",
		children: void 0,
		preloads: ["/assets/blog._slug-B2C0F4Vg.js", "/assets/blog._slug-DycRGvZE.js"]
	},
	"/blog/": {
		filePath: "/Users/utkarsh/Desktop/thesocial99_reviews/src/routes/blog.index.tsx",
		children: void 0,
		preloads: ["/assets/blog.index-6A3orQLe.js"]
	}
} });
//#endregion
export { tsrStartManifest };
